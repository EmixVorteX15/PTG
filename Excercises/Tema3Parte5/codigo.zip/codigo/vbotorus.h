#ifndef VBOTORUS_H
#define VBOTORUS_H

void generateVerts(float * , float * ,float *, unsigned int *, float , float, int, int);

#endif // VBOTORUS_H
